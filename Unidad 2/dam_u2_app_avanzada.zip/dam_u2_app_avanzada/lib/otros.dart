import 'package:flutter/material.dart';

class Otros extends StatefulWidget {
  const Otros({Key? key}) : super(key: key);

  @override
  State<Otros> createState() => _OtrosState();
}

List<String> opc = ["Pentágono", "Heptágono", "Hexágono"];
enum opcRB { opc1, opc2 }

class _OtrosState extends State<Otros> {

  String valor = opc.first;
  opcRB _sel = opcRB.opc1;
  String _res = "";
  bool enaApo = true;
  final lado = TextEditingController();
  final apo = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.only(left: 60, top: 30, right: 60),
      children: [
        Text(
          "Elige la figura: ",
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        SizedBox(
          height: 20,
        ),
        DropdownButton(
          value: valor,
          items: opc.map<DropdownMenuItem<String>>((String valor) {
            return DropdownMenuItem<String>(
              value: valor,
              child: Text(valor),
            );
          }).toList(),
          isExpanded: true,
          focusColor: Colors.white,
          onChanged: (String? val) {
            setState(() {
              valor = val!;
              evaluar();
            });
          },
        ),
        SizedBox(
          height: 20,
        ),
        TextField(
          controller: lado,
          decoration: InputDecoration(
              label: Text("Lado: "), border: OutlineInputBorder()),
        ),
        SizedBox(
          height: 20,
        ),
        TextField(
          controller: apo,
          enabled: enaApo,
          decoration: InputDecoration(
              label: Text("Apotema: "), border: OutlineInputBorder()),
        ),
        SizedBox(
          height: 20,
        ),
        Row(
          children: [
            SizedBox(
              width: 200,
              child: ListTile(
                title: Text("Área"),
                leading: Radio(
                  value: opcRB.opc1,
                  groupValue: _sel,
                  onChanged: (opcRB? sel) {
                    setState(() {
                      _sel = sel!;
                      evaluar();
                    });
                  },
                ),
              ),
            ),
            SizedBox(
                width: 200,
                child: ListTile(
                  title: Text("Perímetro"),
                  leading: Radio(
                    value: opcRB.opc2,
                    groupValue: _sel,
                    onChanged: (opcRB? sel) {
                      setState(() {
                        _sel = sel!;
                        evaluar();
                      });
                    },
                  ),
                ))
          ],
        ),
        Padding(
          padding: EdgeInsets.only(left: 70, top: 10, right: 70),
          child: SizedBox(
            height: 50,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  if(lado.text.replaceAll(" ", "") == ""){
                    showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text("Error"),
                            content: Text("Campo vacío"),
                            actions: [
                              TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Text("Ok"))
                            ],
                          );
                        });
                    return ;
                  }
                  if(_sel == opcRB.opc1 && apo.text.replaceAll(" ", "") == ""){
                    showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text("Error"),
                            content: Text("Campo vacío"),
                            actions: [
                              TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Text("Ok"))
                            ],
                          );
                        });
                    return ;
                  }

                  if(_sel == opcRB.opc1){
                    if(valor == "Pentágono"){
                      _res = (double.parse(lado.text) * double.parse(apo.text) * 5 / 2).toString();
                    } else if(valor == "Heptágono"){
                      _res = (double.parse(lado.text) * double.parse(apo.text) * 6 / 2).toString();
                    } else if(valor == "Hexágono"){
                      _res = (double.parse(lado.text) * double.parse(apo.text) * 7 / 2).toString();
                    }
                  } else {
                    if(valor == "Pentágono"){
                      _res = (double.parse(lado.text) * 5).toString();
                    } else if(valor == "Heptágono"){
                      _res = (double.parse(lado.text) * 6).toString();
                    } else if(valor == "Hexágono"){
                      _res = (double.parse(lado.text) * 7).toString();
                    }
                  }
                  lado.clear();
                  apo.clear();
                });
              },
              child: Text(
                "Calcular",
                style: TextStyle(fontSize: 25),
              ),
            ),
          ),
        ),
        SizedBox(height: 20,),
        Text("El resultado es: ",
            style: TextStyle(fontSize: 20), textAlign: TextAlign.center),
        SizedBox(height: 10,),
        Text(
          _res,
          style: TextStyle(
              fontSize: 40, fontWeight: FontWeight.bold, color: Colors.blue),
          textAlign: TextAlign.center,
        )
      ],
    );
  }

  void evaluar() {
    if(_sel == opcRB.opc1){
      enaApo = true;
    }else{
      enaApo = false;
    }
  }
}

