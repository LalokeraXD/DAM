import 'package:flutter/material.dart';

class Cuadrilateros extends StatefulWidget {
  const Cuadrilateros({Key? key}) : super(key: key);

  @override
  State<Cuadrilateros> createState() => _CuadrilaterosState();
}

List<String> opc = ["Cuadrado", "Rescángulo"];
enum opcRB { opc1, opc2 }

class _CuadrilaterosState extends State<Cuadrilateros> {
  String valor = opc.first;
  opcRB _sel = opcRB.opc1;
  String _res = "";
  bool ena = false;
  final base = TextEditingController();
  final alt = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: EdgeInsets.only(left: 60, top: 30, right: 60),
      children: [
        Text(
          "Elige la figura: ",
          style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold),
          textAlign: TextAlign.center,
        ),
        SizedBox(
          height: 20,
        ),
        DropdownButton(
          value: valor,
          items: opc.map<DropdownMenuItem<String>>((String valor) {
            return DropdownMenuItem<String>(
              value: valor,
              child: Text(valor),
            );
          }).toList(),
          isExpanded: true,
          focusColor: Colors.white,
          onChanged: (String? val) {
            setState(() {
              valor = val!;
              if(valor == "Cuadrado"){
                ena = false;
              }else{
                ena = true;
              }
            });
          },
        ),
        SizedBox(
          height: 20,
        ),
        TextField(
          controller: base,
          decoration: InputDecoration(
              label: Text("Base: "), border: OutlineInputBorder()),
        ),
        SizedBox(
          height: 20,
        ),
        TextField(
          controller: alt,
          enabled: ena,
          decoration: InputDecoration(
              label: Text("Altura: "), border: OutlineInputBorder()),
        ),
        SizedBox(
          height: 20,
        ),
        Row(
          children: [
            SizedBox(
              width: 200,
              child: ListTile(
                title: Text("Área"),
                leading: Radio(
                  value: opcRB.opc1,
                  groupValue: _sel,
                  onChanged: (opcRB? sel) {
                    setState(() {
                      _sel = sel!;
                      if(valor == "Cuadrado"){
                        ena = false;
                      }else{
                        ena = true;
                      }
                      /*if(_sel == opcRB.opc1){
                        ena = false;
                      }else if(_sel == opcRB.opc2){
                        if(valor == "Cuadrado"){
                          ena = false;
                        } else if(valor == "Rectángulo"){
                          ena = true;
                        }
                      }*/
                    });
                  },
                ),
              ),
            ),
            SizedBox(
                width: 200,
                child: ListTile(
                  title: Text("Perímetro"),
                  leading: Radio(
                    value: opcRB.opc2,
                    groupValue: _sel,
                    onChanged: (opcRB? sel) {
                      setState(() {
                        _sel = sel!;
                      });
                    },
                  ),
                ))
          ],
        ),
        Padding(
          padding: EdgeInsets.only(left: 70, top: 10, right: 70),
          child: SizedBox(
            height: 50,
            child: ElevatedButton(
              onPressed: () {
                setState(() {
                  if(base.text.replaceAll(" ", "") == ""){
                    showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return AlertDialog(
                            title: Text("Error"),
                            content: Text("Campo vacío"),
                            actions: [
                              TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Text("Ok"))
                            ],
                          );
                        });
                    return ;
                  }
                  if(ena == false){
                    if(_sel == opcRB.opc1){
                      _res = (double.parse(base.text) * double.parse(base.text)).toString();
                    }else{
                      _res = (double.parse(base.text) * 4).toString();
                    }
                  }else{
                    if(alt.text.replaceAll(" ", "") == ""){
                      showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text("Error"),
                              content: Text("Campo vacío"),
                              actions: [
                                TextButton(
                                    onPressed: () {
                                      Navigator.of(context).pop();
                                    },
                                    child: Text("Ok"))
                              ],
                            );
                          });
                      return ;
                    }
                    if(_sel == opcRB.opc1){
                      _res = (double.parse(base.text) * double.parse(alt.text)).toString();
                    }else{
                      _res = (double.parse(base.text) * 2 + double.parse(alt.text) * 2).toString();
                    }
                  }
                  alt.clear();
                  base.clear();
                });
              },
              child: Text(
                "Calcular",
                style: TextStyle(fontSize: 25),
              ),
            ),
          ),
        ),
        SizedBox(height: 20,),
        Text("El resultado es: ",
            style: TextStyle(fontSize: 20), textAlign: TextAlign.center),
        SizedBox(height: 10,),
        Text(
          _res,
          style: TextStyle(
              fontSize: 40, fontWeight: FontWeight.bold, color: Colors.blue),
          textAlign: TextAlign.center,
        )
      ],
    );
  }
}
