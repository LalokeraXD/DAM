import 'package:dam_u2_app_avanzada/cuadrilateros.dart';
import 'package:dam_u2_app_avanzada/otros.dart';
import 'package:dam_u2_app_avanzada/triangulos.dart';
import 'package:flutter/material.dart';

class Principal extends StatefulWidget {
  const Principal({Key? key}) : super(key: key);

  @override
  State<Principal> createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> {

  int _i = 0;

  final List<Widget> _pag = [
    Cuadrilateros(),
    Triangulos(),
    Otros()
  ];

  void _cambiar(int i){
    setState(() {
      _i = i;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Geometría", style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 35
        ),),
        centerTitle: true,
        toolbarHeight: 75,
        actions: [
          //IconButton(onPressed: (){}, icon: Icon(Icons.adb))
        ],
        backgroundColor: Colors.blue,
      ),
      body: _pag[_i],
      bottomNavigationBar: BottomNavigationBar(
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.square_outlined), label: "Cuadriláteros"),
          BottomNavigationBarItem(icon: Icon(Icons.square_foot), label: "Triángulos"),
          BottomNavigationBarItem(icon: Icon(Icons.pentagon_outlined), label: "Otros"),
        ],
        currentIndex: _i,
        backgroundColor: Colors.blueGrey,
        iconSize: 20,
        selectedItemColor: Colors.white,
        unselectedItemColor: Colors.white54,
        onTap: _cambiar,
      ),
    );
  }
}

