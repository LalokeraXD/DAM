package com.example.dam_u2_app_avanzada

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
