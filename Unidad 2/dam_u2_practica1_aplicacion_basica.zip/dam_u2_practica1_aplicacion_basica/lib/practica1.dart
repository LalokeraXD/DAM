import 'dart:math';

import 'package:flutter/material.dart';

class Practica1 extends StatefulWidget {
  const Practica1({Key? key}) : super(key: key);

  @override
  State<Practica1> createState() => _Practica1State();
}

class _Practica1State extends State<Practica1> {
  final txtF1 = TextEditingController();
  final txtF2 = TextEditingController();
  String IMC = "", txt = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Calculadora del IMC",
            style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
        centerTitle: true,
        foregroundColor: Colors.white,
        actions: [
          IconButton(
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (BuildContext context) {
                      return AlertDialog(
                        title: Text("Clasificación",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                                fontSize: 30,
                                fontWeight: FontWeight.bold,
                                color: Colors.lightGreen)),
                        content: SizedBox(
                          height: 120,
                          width: 350,
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                            children: [
                              Column(
                                children: [
                                  Text(
                                    "IMC",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text("Menos de 18.5"),
                                  Text("18.5 - 24.9"),
                                  Text("25 - 29.9"),
                                  Text("Más de 30"),
                                ],
                              ),

                              Column(
                                children: [
                                  Text(
                                    "Composición corporal",
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Text("Peso inferior al normal"),
                                  Text("Normal"),
                                  Text("Peos superior al normal"),
                                  Text("Obesidad"),
                                ],
                              ),
                            ],
                          ),
                        ),
                        actions: [
                          TextButton(
                              onPressed: () {
                                Navigator.of(context).pop();
                              },
                              child: Text("Ok"))
                        ],
                      );
                    });
              },
              icon: Icon(Icons.info))
        ],
      ),
      body: Column(
        //padding: EdgeInsets.all(100),
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text("Índice de masa corporal",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 30, color: Colors.lightGreen)),
          SizedBox(
            height: 30,
          ),
          //Text("Ingrese su peso", textAlign: TextAlign.center, style: TextStyle(fontSize: 20,)),
          Padding(
              padding: EdgeInsets.all(20),
              child: TextField(
                controller: txtF1,
                decoration: InputDecoration(
                    icon: Icon(Icons.accessibility),
                    labelText: "Ingrese su altura (cm)"),
              )),
          Padding(
              padding: EdgeInsets.all(20),
              child: TextField(
                controller: txtF2,
                decoration: InputDecoration(
                    icon: Icon(Icons.fastfood),
                    labelText: "Ingrese su peso (kg)"),
              )),
          SizedBox(
              width: 180,
              height: 45,
              child: ElevatedButton(
                  onPressed: () {
                    setState(() {
                      IMC = calc(txtF2.text, txtF1.text);
                      txt = "Su IMC es:";
                    });
                  },
                  child: Text(
                    "Calcular",
                    style: TextStyle(fontSize: 20, color: Colors.white),
                  ))),
          SizedBox(
            height: 30,
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: Text(txt, textAlign: TextAlign.center),
          ),
          Padding(
            padding: EdgeInsets.all(5),
            child: Text(IMC,
                style: TextStyle(
                    fontSize: 40,
                    color: Colors.orange,
                    fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
        ],
      ),
    );
  }

  String calc(String txt1, String txt2) {
    return (double.parse(txt1) / pow((double.parse(txt2)) / 100, 2))
        .toStringAsFixed(2)
        .toString();
  }
}
